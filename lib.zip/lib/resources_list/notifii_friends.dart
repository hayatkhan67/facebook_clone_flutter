import '../model class/friends_details.dart';

List friends = [
  Wahab(
    dp: 'assets/facebook/friends/images/photo_2023-07-15_21-12-19.jpg',
    name: 'Wahab Niazi',
    totalFriends: '6',
  ),
  Kamran(
    dp: 'assets/facebook/friends/images/photo_2023-07-16_20-36-31.jpg',
    name: 'Kamran Niazi',
    totalFriends: '6',
  ),
  Amjad(
      dp: 'assets/facebook/friends/images/photo_2023-07-15_21-12-22.jpg',
      name: 'Amjad',
      totalFriends: '6'),
  Shan(
    dp: 'assets/facebook/friends/images/photo_1_2023-07-10_20-06-17.jpg',
    name: 'Shan Niazi',
    totalFriends: '6',
  ),
  Zain(
    dp: 'assets/facebook/friends/images/photo_2023-07-15_21-11-48.jpg',
    name: 'Zain Khan Niazi',
    totalFriends: '6',
  ),
  KhanAmir(
    dp: 'assets/facebook/friends/images/photo_6_2023-07-10_20-06-17.jpg',
    name: 'Khan Amir Niazi',
    totalFriends: '6',
  ),
];
List friendRequest = [
  HknGaming(
      dp: 'assets/facebook/friends/images/photo_2023-07-15_21-12-15.jpg',
      name: 'HKN Gaming',
      totalFriends: '6'),
  Hasan(
      dp: 'assets/facebook/friends/images/photo_2023-07-18_15-37-01.jpg',
      name: 'Hasan Niazi',
      totalFriends: '6'),
  AliSami(
      dp: 'assets/facebook/friends/images/photo_2023-07-18_15-37-05.jpg',
      name: 'AliSami',
      totalFriends: '6'),
  Unknown(
      dp: 'assets/facebook/friends/images/photo_2023-07-18_15-42-23.jpg',
      name: 'HKN playz',
      totalFriends: '6'),
];
// List notifi = ['added a new post', 'liked your post'];
