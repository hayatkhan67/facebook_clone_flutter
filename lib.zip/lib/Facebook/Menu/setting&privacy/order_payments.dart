import 'package:flutter/material.dart';

class OrderPayment extends StatelessWidget {
  const OrderPayment({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
