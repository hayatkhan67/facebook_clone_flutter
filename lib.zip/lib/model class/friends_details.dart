class Wahab {
  String? name;
  String? dp;
  String? posts;
  String? postText;
  String? totalFriends;
  List? displayFriendsImage;

  Wahab(
      {this.name,
      this.dp,
      this.posts,
      this.postText,
      this.displayFriendsImage,
      this.totalFriends});
}

class Kamran {
  String? name;
  String? dp;
  String? posts;
  String? postText;
  String? totalFriends;
  List? displayFriendsImage;

  Kamran(
      {this.name,
      this.dp,
      this.posts,
      this.postText,
      this.displayFriendsImage,
      this.totalFriends});
}

class Amjad {
  String? name;
  String? dp;
  String? posts;
  String? postText;
  String? totalFriends;
  List? displayFriendsImage;

  Amjad(
      {this.name,
      this.dp,
      this.posts,
      this.postText,
      this.displayFriendsImage,
      this.totalFriends});
}

class Zain {
  String? name;
  String? dp;
  String? posts;
  String? postText;
  String? totalFriends;
  List? displayFriendsImage;

  Zain(
      {this.name,
      this.dp,
      this.posts,
      this.postText,
      this.displayFriendsImage,
      this.totalFriends});
}

class Shan {
  String? name;
  String? dp;
  String? posts;
  String? postText;
  String? totalFriends;
  List? displayFriendsImage;

  Shan(
      {this.name,
      this.dp,
      this.posts,
      this.postText,
      this.displayFriendsImage,
      this.totalFriends});
}

class KhanAmir {
  String? name;
  String? dp;
  String? posts;
  String? postText;
  String? totalFriends;
  List? displayFriendsImage;

  KhanAmir(
      {this.name,
      this.dp,
      this.posts,
      this.postText,
      this.displayFriendsImage,
      this.totalFriends});
}

class HknGaming {
  String? name;
  String? dp;
  String? posts;
  String? postText;
  String? totalFriends;
  List? displayFriendsImage;

  HknGaming(
      {this.name,
      this.dp,
      this.posts,
      this.postText,
      this.displayFriendsImage,
      this.totalFriends});
}

class Hasan {
  String? name;
  String? dp;
  String? posts;
  String? postText;
  String? totalFriends;
  List? displayFriendsImage;

  Hasan(
      {this.name,
      this.dp,
      this.posts,
      this.postText,
      this.displayFriendsImage,
      this.totalFriends});
}

class AliSami {
  String? name;
  String? dp;
  String? posts;
  String? postText;
  String? totalFriends;
  List? displayFriendsImage;

  AliSami(
      {this.name,
      this.dp,
      this.posts,
      this.postText,
      this.displayFriendsImage,
      this.totalFriends});
}

class Unknown {
  String? name;
  String? dp;
  String? posts;
  String? postText;
  String? totalFriends;
  List? displayFriendsImage;

  Unknown(
      {this.name,
      this.dp,
      this.posts,
      this.postText,
      this.displayFriendsImage,
      this.totalFriends});
}
